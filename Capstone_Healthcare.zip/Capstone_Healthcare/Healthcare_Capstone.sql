CREATE DATABASE HeartDiseaseDB;
USE HeartDiseaseDB;

DROP TABLE IF EXISTS PatientData;

CREATE TABLE PatientData (
    id INT AUTO_INCREMENT PRIMARY KEY,
    age INT,
    sex INT,
    chest_pain_type INT,
    resting_bp INT,
    serum_cholesterol INT,
    fasting_blood_sugar INT,
    resting_ecg INT,
    max_heart_rate INT,
    exercise_induced_angina INT,
    oldpeak FLOAT,
    slope INT,
    num_major_vessels INT,
    thal INT,
    target INT
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/heart.csv'
INTO TABLE PatientData
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(age, sex, chest_pain_type, resting_bp, serum_cholesterol, fasting_blood_sugar, resting_ecg, max_heart_rate, exercise_induced_angina, oldpeak, slope, num_major_vessels, thal, target);

SELECT * FROM PatientData LIMIT 10;

ALTER TABLE PatientData
ADD COLUMN age_group VARCHAR(20);

SET SQL_SAFE_UPDATES = 0;

UPDATE PatientData SET age_group = CASE
    WHEN age BETWEEN 0 AND 30 THEN '0-30'
    WHEN age BETWEEN 31 AND 45 THEN '31-45'
    WHEN age BETWEEN 46 AND 60 THEN '46-60'
    ELSE '60+'
END;

SET SQL_SAFE_UPDATES = 1;

CREATE VIEW AgeGroupView AS
SELECT age_group, COUNT(*) AS TotalPatients
FROM PatientData
GROUP BY age_group;

